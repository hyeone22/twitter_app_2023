import React from 'react'
import { Link } from 'react-router-dom'

function Navigation({userObj}) {
  console.log("userObj->",userObj)
  return (
    <nav>
      <ul>
        <li><Link to={'/'}>Home</Link></li>
        <li><Link to={'/profile'}>{userObj.displayName}의 My Profiles</Link></li>
      </ul>
    </nav>
  )
}

export default Navigation