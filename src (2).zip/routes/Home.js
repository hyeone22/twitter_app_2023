import React, { useEffect, useState } from 'react'
import { collection, addDoc, getDocs, onSnapshot, query, orderBy  } from "firebase/firestore";
import { db, storage } from 'fbase';
import Tweet from 'components/Tweet';
import { v4 as uuidv4 } from 'uuid';
import { ref, uploadString, getDownloadURL  } from "firebase/storage";


function Home({userObj}) {
  console.log(userObj);
  const [tweet, setTweet] = useState("");
  const [tweets, setTweets] = useState([]);
  const [attachment, setAttachment] = useState("");

 /*  const getTweets = async() => {
  const querySnapshot = await getDocs(collection(db, "tweets"));
  querySnapshot.forEach((doc) => {
  console.log(`${doc.id} => ${doc.data()}`);
  const tweetObject = {...doc.data(), id:doc.id}
  setTweets(prev => [tweetObject, ...prev]); //새 트윗을 가장 먼저 보여준다.
  });
  } */

  useEffect(() => { // 글을 썼을때 최신글이 맨 위로 오게 ㅇㅇ
    // getTweets();
    const q = query(collection(db, "tweets"),
                    orderBy("createdAt","desc"));
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const newArray = [];
      querySnapshot.forEach((doc) => {
        newArray.push({...doc.data(), id:doc.id});
      });
      setTweets(newArray);
    });
  },[]);


  const onChange = (e) => {
  e.preventDefault();
  const {target:{value}} = (e);
  setTweet(value);  
  }

  const onSubmit = async (e) => { // submit에 입력되고
  e.preventDefault();
  try {
    let attachmentUrl = "";
    if(attachment !== ""){
    const storageRef = ref(storage, `${userObj.uid}/${uuidv4()}`); // 사진을 스토리지에 저장
    const response = await uploadString(storageRef, attachment, 'data_url');
    console.log('response->',response)
    attachmentUrl = await getDownloadURL(ref(storage, response.ref)) //다운로드하는 url https: 로 저장

    }
    
    const docRef = await addDoc(collection(db, "tweets"), {
      text: tweet,
      createdAt: Date.now(),
      createrId: userObj.uid,  // 문서를 누가 작성했는지 알아내야함 userObj > 로그인한 사용자 정보
      attachmentUrl
    });
    console.log("Document written with ID: ", docRef.id);
    } catch (e) {
      console.error("Error adding document: ", e);
    }
    setTweet("");  // 입력되면 비워야함
    setAttachment("");
  }

  const onFilechange = (e) => { //이미지
    console.log('e->',e);
    const {target: {files}} = e;

    const theFile = files[0];
    console.log('theFile->',theFile); //jpg 이미지 주소

    const reader = new FileReader();
    
    reader.onloadend = (finishedEvent) => {
     console.log('finishedEvent->',finishedEvent);
     const {currentTarget:{result}} = finishedEvent; //data:image
     setAttachment(result); 
    }
    reader.readAsDataURL(theFile);
  }

  const onclearAttachment = () => {
    setAttachment("");
  }

  return (
    <>
      <form onSubmit={onSubmit}>
        <input type='text' placeholder="what's on your mind" value={tweet} onChange={onChange} />
        <input type='file' accept='image/*' onChange={onFilechange}/> 
        <input type='submit' value='tweet' onChange={onChange} />
        {attachment && (
          <div>
            <img src={attachment} width="50" height="50" alt="" />
            <button onClick={onclearAttachment}>Remove</button>
          </div>
        )}
      </form>
      <div>
        {tweets.map(tweet => (
         //  <div key={tweet.id}>
         //   <h4>{tweet.text}</h4>
         // </div>
          <Tweet key={tweet.id} tweetObj={tweet} isOwner={tweet.createrId === userObj.uid} />
        ))}
      </div>
    </>
  )
}

export default Home