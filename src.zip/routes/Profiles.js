import React from 'react'
import { authService } from 'fbase'
import { useNavigate } from 'react-router-dom';

function Profiles() {
  const navigate =  useNavigate(); //location 객체 역활 강제로 주소를 바꿔주는

  const onLogOutClick = () => {
    authService.signOut(); //signOut 로그아웃 메서드
    navigate('/'); //첫화면으로 이동 즉 리다이렉트 기능이다.
  }
  return (
    <>
      <button onClick={onLogOutClick}>Log Out</button>  
    </>
  )
}

export default Profiles