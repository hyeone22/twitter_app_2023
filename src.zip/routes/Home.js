import React, { useEffect, useState } from 'react'
import { collection, addDoc, getDocs, onSnapshot, query, orderBy  } from "firebase/firestore";
import { db } from 'fbase';
import Tweet from 'components/Tweet';


function Home({userObj}) {
  console.log(userObj);
  const [tweet, setTweet] = useState("");
  const [tweets, setTweets] = useState([]);

 /*  const getTweets = async() => {
  const querySnapshot = await getDocs(collection(db, "tweets"));
  querySnapshot.forEach((doc) => {
  console.log(`${doc.id} => ${doc.data()}`);
  const tweetObject = {...doc.data(), id:doc.id}
  setTweets(prev => [tweetObject, ...prev]); //새 트윗을 가장 먼저 보여준다.
  });
  } */

  useEffect(() => { // 글을 썼을때 최신글이 맨 위로 오게 ㅇㅇ
    // getTweets();
    const q = query(collection(db, "tweets"),
                    orderBy("createdAt","desc"));
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const newArray = [];
      querySnapshot.forEach((doc) => {
        newArray.push({...doc.data(), id:doc.id});
      });
      setTweets(newArray);
    });
  },[]);


  const onChange = (e) => {
  e.preventDefault();
  const {target:{value}} = (e);
  setTweet(value);  
  }

  const onSubmit = async (e) => { // submit에 입력되고
  e.preventDefault();
  try {
    const docRef = await addDoc(collection(db, "tweets"), {
      text: tweet,
      createdAt: Date.now(),
      createrId: userObj.uid,  // 문서를 누가 작성했는지 알아내야함 userObj > 로그인한 사용자 정보
    });
    console.log("Document written with ID: ", docRef.id);
    } catch (e) {
      console.error("Error adding document: ", e);
    }
    setTweet("");  // 입력되면 비워야함
  }

  return (
    <>
      <form onSubmit={onSubmit}>
        <input type='text' placeholder="what's on your mind" value={tweet} onChange={onChange} />
        <input type='submit' value='tweet' onChange={onChange} />  
      </form>
      <div>
        {tweets.map(tweet => (
         //  <div key={tweet.id}>
         //   <h4>{tweet.text}</h4>
         // </div>
          <Tweet key={tweet.id} tweetObj={tweet} isOwner={tweet.createrId === userObj.uid} />
        ))}
      </div>
    </>
  )
}

export default Home