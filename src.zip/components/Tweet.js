import React, { useState } from 'react'
import { db } from 'fbase';
import { doc, deleteDoc } from "firebase/firestore";


function Tweet(props) {
  console.log("props->",props);
const{tweetObj:{text,id},isOwner} = props;
const[editing, setEditing] = useState(false);

const onDeleteClick = async() => {
  const ok = window.confirm("삭제하시겠습니까?");
  if(ok){
    const data = await deleteDoc(doc(db, "tweets", `/${id}`));
  }
}

const toggleEditing = () => setEditing((prev) => !prev); //토글기능

  return (
  <div>
     {editing ? (
      <>
        <button onClick={toggleEditing}>Cancel</button>
      </>
     ) : (
      <>
        <h4>{text}</h4>
          {isOwner && (
          <>
          <button onClick={onDeleteClick}>Delete Tweet</button>
          <button onClick={toggleEditing}>Edit Tweet</button> 
          </>
         )}      
      </>
     )}
  </div>
  )
}
export default Tweet
                 


// import React from 'react'

// function Tweet({tweetObj}) {
//   console.log("twwetObj ->",tweetObj);
//   return (
//     <div>
//       <h4>{tweetObj.text}</h4>
//       <button>Delete Tweet</button>
//       <button>Edit Tweet</button>
//     </div>
//   )
// }

// export default Tweet