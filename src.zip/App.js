import { useEffect, useState } from "react";
import AppRouter from "Router";
import { authService } from "fbase";
import { onAuthStateChanged } from "firebase/auth";



function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(authService.currentUser); // 처음엔 로그인이 안되있으니까
  console.log('authService.currentUser ->' ,authService.currentUser ) // currentUser는 현재 로그인한 사람 확인 함수
  
  const [userObj, setUserObj] = useState(null);

  useEffect(() => { 
    onAuthStateChanged(authService, (user) => {
      console.log('user->',user);
      if (user) {
          setIsLoggedIn(user);
          setUserObj(user);
      } else {
          setIsLoggedIn(false);
      }
    });    
  },[]);

  return (
  <>
   <AppRouter isLoggedIn={isLoggedIn} userObj={userObj} />
   <footer>&copy; {new Date().getFullYear()} Twitter app</footer>
  </>   
  );
}

export default App;
